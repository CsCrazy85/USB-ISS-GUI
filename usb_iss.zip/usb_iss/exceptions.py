class UsbIssError(Exception):
    pass
